Requeriments (Extensions que he afegit al visual studio code):
-C#
-NuGet Package Manager (Al NuGet Package Manager he instal·lat varis plugins de proves WEB)
	-Selenium.WebDriver.ChromeDriver (Última Versió Estable)
	-Selenium.WebDriver (Última Versió Estable)
	-NUnit (Última Versió Estable)
	-NUnit3TestAdapter (Última Versió Estable)
	-Microsoft.TestPlatform.TestHost (Última Versió Estable)

Utilització
-Per a utilitzar el programa es requereix del programa Visual Studio Code i obrir el projecte del programa, un cop obert, obrir el program.cs i editar les lineas de codi 17, 19 i 22 en funció de la prova que s'estigui fent (si es la primera Brave_1 per exemple) i de la ruta del programa al teu ordinaro.
 Després si es desitja canviar les iteracions del for per a canviar el número de proves a realitzar per a cada navegador i les rutes dels drivers de les lineas de codis: 30, 33, 34, 46, 48, 49.
 Per últim prémer el botó de "Run Test" i esperar a que acabi, els resultats es guardaran a la carpeta que hagis especificat a la linea 17 i 19.

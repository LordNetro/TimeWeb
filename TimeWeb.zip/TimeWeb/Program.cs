﻿using System;
using System.IO;
using OpenQA.Selenium; //Selenium és un entorn de proves de software per aplicacions basades en Web
using OpenQA.Selenium.Opera;
using OpenQA.Selenium.Chrome;
using NUnit.Framework; //NUnit es un framework de probes d'unitat (comprovar el correcte funcionament de una unitat de codi)

namespace TimeWeb
{
    class Program
    {

        [Test]
        public static void Main()
        {
            //Definim per a cada navegador, a on volem desar els resultats.
            string path_b = @"X:\Ruta\a\BraveTest_x.txt"; 
            StreamWriter wb = File.CreateText(path_b);
            string path_o = @"X:\Ruta\a\EpicTest_x.txt";
            StreamWriter wo = File.CreateText(path_o);
            //Llegim la Base de Dades de URLs de pàgines WEB.
            string[] lines = File.ReadAllLines(@"X:\Ruta\a\database.txt");
            Random rand = new Random();
            //Comença el bucle, per a cada Navegador es realitzen 25 iteracions (25 pàgines WEB)
            for (int i = 0; i < 25; ++i)
            {
                //Brave
                //Seleccionem aleatòriament una URL de la Base de Dades
                string url = lines[rand.Next(lines.Length)];
                System.Environment.SetEnvironmentVariable("webdriver.chrome.driver",@"X:\Ruta\a\chromedriver.exe");
                ChromeOptions options = new ChromeOptions();
                //Definim la ubicació del Navegador Brave
                options.BinaryLocation = @"X:\Ruta\a\Brave.exe";
                WebDriver driver_b = new ChromeDriver(@"X:\Ruta\a\chromedriver_win32_b\",options);
                System.Diagnostics.Stopwatch timer = new System.Diagnostics.Stopwatch();
                //Fem la prova de execució amb la URL obtinguda i mesurem el temps
                timer.Start();
                driver_b.Navigate().GoToUrl("https://" + url);
                timer.Stop();
                TimeSpan timeTaken = timer.Elapsed;
                driver_b.Close();
                //Desem a un fitxer TXT els resultats
                wb.WriteLine("URL: " + url + " Time: " + timeTaken.ToString() + "\n");

                //Es fa el mateix per al navegador Epic
                System.Environment.SetEnvironmentVariable("webdriver.chrome.driver",@"X:\Ruta\a\chromedriver.exe");
                ChromeOptions options2 = new ChromeOptions();
                options2.BinaryLocation = @"X:\Ruta\a\epic.exe";
                IWebDriver driver_o = new ChromeDriver(@"X:\Ruta\a\chromedriver_win32_e\",options2);
                System.Diagnostics.Stopwatch timer2 = new System.Diagnostics.Stopwatch();
                timer2.Start();
                driver_o.Navigate().GoToUrl("https://" + url);
                timer2.Stop();
                TimeSpan timeTaken2 = timer2.Elapsed;
                driver_o.Close();
                wo.WriteLine("URL: " + url + " Time: " + timeTaken2.ToString() + "\n");
            }
            wb.Close();
            wo.Close();
        }
    }
}